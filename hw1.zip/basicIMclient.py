import MyMessage_pb2
import socket
import argparse
import sys
import struct
import select

parser = argparse.ArgumentParser()
parser.add_argument('-s', dest='server', help='name of server', required=True)
parser.add_argument('-n', dest='name', help='nickname', required=True)
args = parser.parse_args()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


s.connect((args.server, 9999))


read_handles = [sys.stdin, s]

# proto
mymessage = MyMessage_pb2.mymessage()

while True:
    ready_to_read_list, _, _ = select.select(read_handles, [], [])

    # user input
    for item in ready_to_read_list:
        if item is sys.stdin:
            # user_input = input()
            user_input = sys.stdin.readline().strip('\n')
            mymessage.name = args.name+': '
            mymessage.message = user_input
            data = mymessage.SerializeToString()
            s.send(data)

    # message sent by other user
        else:
            data = s.recv(4096)
            mymessage.ParseFromString(data)
            # print(mymessage.name + mymessage.message)
            sys.stdout.write(mymessage.name + mymessage.message+'\n')
            sys.stdout.flush()



