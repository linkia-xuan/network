import socket
import select
import sys
import struct
import signal



s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)

s.bind(('', 9999))

s.listen(5)

recv_handles = [s]



while True:

    ready_to_read_list, _, _ = select.select(recv_handles, [], [])

    for item in ready_to_read_list:
        # connection from client
            if item is s:
                conn,addr = s.accept()
                recv_handles.append(conn)

        #send to other client
            else:
                data = item.recv(4096)
                for connlxz in recv_handles[1:]:
                    if connlxz is not item:
                        connlxz.send(data)



